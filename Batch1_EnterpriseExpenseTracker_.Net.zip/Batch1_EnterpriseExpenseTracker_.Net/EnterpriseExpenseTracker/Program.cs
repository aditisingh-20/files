using EnterpriseExpenseTracker.Models;
//using EnterpriseExpenseTracker.Models;
using Swashbuckle.AspNetCore;
namespace EnterpriseExpenseTracker
{
    public class Program
    {
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddSwaggerGen();
            //services.AddCors(options =>
            //{
            //    options.AddDefaultPolicy(builder =>
            //    {
            //        builder.WithOrigins("http://localhost:3000/")
            //        .AllowAnyHeader()
            //        .AllowAnyMethod();
            //    });
            //});
        }
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            
            builder.Services.AddControllers();
            builder.Services.AddDbContext<EnterpriseExpenseTrackerContext>();
            builder.Services.AddSwaggerGen();
            var app = builder.Build();

            // Configure the HTTP request pipeline.
            app.UseCors(x => x
                .AllowAnyOrigin()
                .AllowAnyMethod()
                .AllowAnyHeader());
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Expenses API");
            });
            app.UseAuthorization();
           


            app.MapControllers();

            app.Run();
        }
    }
}
