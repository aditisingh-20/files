﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EnterpriseExpenseTracker.Models;
using Microsoft.DotNet.Scaffolding.Shared.Messaging;

namespace EnterpriseExpenseTracker.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TblExpensesController : ControllerBase
    {
        private readonly EnterpriseExpenseTrackerContext _context;

        public TblExpensesController(EnterpriseExpenseTrackerContext context)
        {
            _context = context;
        }

        // GET: api/TblExpenses
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TblExpense>>> GetTblExpenses()
        {
            return await _context.TblExpenses.ToListAsync();
        }

        //GET: api/TblExpenses/5
        [HttpGet("expense/{id}")]
        public async Task<ActionResult<TblExpense>> GetTblExpense(int id)
        {
            var tblExpense = await _context.TblExpenses.FindAsync(id);

            if (tblExpense == null)
            {
                return NotFound();
            }

            return tblExpense;
        }

        // PUT: api/TblExpenses/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutTblExpense(int id, TblExpense tblExpense)
        {
            if (id != tblExpense.ExpenseId)
            {
                return BadRequest();
            }

            _context.Entry(tblExpense).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TblExpenseExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/TblExpenses
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<TblExpense>> PostTblExpense(TblExpense tblExpense)
        {
            _context.TblExpenses.Add(tblExpense);
            await _context.SaveChangesAsync();

            return Ok(new {message ="Successfull"});
        }

        // DELETE: api/TblExpenses/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTblExpense(int id)
        {
            var tblExpense = await _context.TblExpenses.FindAsync(id);
            if (tblExpense == null)
            {
                return NotFound();
            }

            _context.TblExpenses.Remove(tblExpense);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool TblExpenseExists(int id)
        {
            return _context.TblExpenses.Any(e => e.ExpenseId == id);
        }

        [HttpGet("{employeeId}")]
        public IActionResult GetExpenses(int employeeId)
        {
            var filteredExpenses = _context.TblExpenses.Where(e => e.EmployeeId == employeeId).ToList();

            return Ok(filteredExpenses);
        }

        [HttpGet("{managerId}/expenses")]
        public IActionResult GetExpense(int managerId)
        {
            var filteredExpenses = _context.TblExpenses.Where(e => e.ManagerId == managerId).ToList();

            return Ok(filteredExpenses);
        }

        [HttpPost("UpdateStatus")]
        public async Task<IActionResult> UpdateStatus([FromBody] StatusUpdate statusUpdate)
        {
            var employee = await _context.TblExpenses.FirstOrDefaultAsync(e=>e.ExpenseId== statusUpdate.ExpenseId);
            if(employee == null)
            {
                return NotFound();
            }

            employee.Status = statusUpdate.Status;
            await _context.SaveChangesAsync();

            return NoContent();

        }



    }
}
