﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EnterpriseExpenseTracker.Models;

namespace EnterpriseExpenseTracker.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TblEmployeesController : ControllerBase
    {
        private readonly EnterpriseExpenseTrackerContext _context;

        public TblEmployeesController(EnterpriseExpenseTrackerContext context)
        {
            _context = context;
        }

        // GET: api/TblEmployees
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TblEmployee>>> GetTblEmployees()
        {
            return await _context.TblEmployees.ToListAsync();
        }

        // GET: api/TblEmployees/5
        [HttpGet("{id}")]
        public async Task<ActionResult<TblEmployee>> GetTblEmployee(int id)
        {
            var tblEmployee = await _context.TblEmployees.FindAsync(id);

            if (tblEmployee == null)
            {
                return NotFound();
            }

            return tblEmployee;
        }

        // PUT: api/TblEmployees/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutTblEmployee(int id, TblEmployee tblEmployee)
        {
            if (id != tblEmployee.EmployeeId)
            {
                return BadRequest();
            }

            _context.Entry(tblEmployee).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TblEmployeeExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/TblEmployees
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        //Register
        public async Task<ActionResult<TblEmployee>> PostTblEmployee(TblEmployee tblEmployee)
        {
            if (!ModelState.IsValid)
            {
                return Ok(new { message =( "Invalid credentials" ) });

            }

            
            _context.TblEmployees.Add(tblEmployee);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetTblEmployee", new { id = tblEmployee.EmployeeId }, tblEmployee);
        }

        // DELETE: api/TblEmployees/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTblEmployee(int id)
        {
            var tblEmployee = await _context.TblEmployees.FindAsync(id);
            if (tblEmployee == null)
            {
                return NotFound();
            }

            _context.TblEmployees.Remove(tblEmployee);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool TblEmployeeExists(int id)
        {
            return _context.TblEmployees.Any(e => e.EmployeeId == id);
        }

        [HttpPost("{credentials.EmployeeId}")]
        public IActionResult UserLogin(EmployeeCredentials credentials)
        {
            var employee = _context.TblEmployees.FirstOrDefault(e => e.EmployeeId == credentials.EmployeeId && e.Password == credentials.Password);
            if (employee != null)
            {
                string designation = employee.Designation;
                int id = employee.EmployeeId;
                // You can customize the response based on your needs
                if (designation == "Manager")
                {
                    // Return the designation in the response
                    return Ok(new { message = "Login successful", designation = designation,id=id });
                }
                else
                {
                    // Return the designation in the response
                    return Ok(new { message = "Login successful", designation = designation,id=id });
                }

            }
            else
            {
                return BadRequest(new { message = "Invalid employee credentials" });
            }
        }

        //[HttpGet("{employeeName}")]
        //public async Task<ActionResult<TblEmployee>> GetEmployee(string employeeName)
        //{
        //    var tblEmployee = await _context.TblEmployees.Where(e => e.EmployeeName== employeeName);

        //    if (tblEmployee == null)
        //    {
        //        return NotFound();
        //    }

        //    return tblEmployee;
        //}

    }
}
