﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace EnterpriseExpenseTracker.Models;

public partial class TblEmployee
{
    
    public int EmployeeId { get; set; }

    [Required(ErrorMessage ="Employee Name is Required")]
    public required string EmployeeName { get; set; }

    [Required(ErrorMessage = "Designation is Required")]
    public required string Designation { get; set; }

    [Required(ErrorMessage = "Project is Required")]
    public required string Project { get; set; }

    [Required]
    [DataType(DataType.Password)]
    public required string Password { get; set; }
}
