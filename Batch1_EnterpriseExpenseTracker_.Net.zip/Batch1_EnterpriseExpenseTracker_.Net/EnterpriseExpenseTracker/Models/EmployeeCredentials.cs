﻿namespace EnterpriseExpenseTracker.Models
{
    public class EmployeeCredentials
    {
        public required int EmployeeId { get; set; }
        public required string Password { get; set; }
    }

}
