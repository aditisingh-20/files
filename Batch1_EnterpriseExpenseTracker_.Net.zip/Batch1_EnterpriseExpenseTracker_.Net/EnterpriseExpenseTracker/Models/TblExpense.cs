﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using Xunit;
using Xunit.Sdk;

namespace EnterpriseExpenseTracker.Models;

public partial class TblExpense
{
    public int ExpenseId { get; set; }


    public required int EmployeeId { get; set; }

    [Required(ErrorMessage="Date of Request is required")]
    public required DateTime DateOfRequest { get; set; }

    [Required(ErrorMessage = "Expense Type is required")]
    public required string ExpenseType { get; set; }

    [Required(ErrorMessage = "Amount is required")]
    public decimal Amount { get; set; }

    [Required(ErrorMessage = "Expense Description is required")]
    public required string ExpenseDescription { get; set; }

    
    public required string Status { get; set; }


    public int ManagerId { get; set; }

    [Required(ErrorMessage = "ManagerName is required")]
    public required string ManagerName { get; set; }
}
