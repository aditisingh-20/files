﻿namespace EnterpriseExpenseTracker.Models
{
    public class StatusUpdate
    {
        public int ExpenseId { get; set; }
        public string Status { get; set; }

    }
}
