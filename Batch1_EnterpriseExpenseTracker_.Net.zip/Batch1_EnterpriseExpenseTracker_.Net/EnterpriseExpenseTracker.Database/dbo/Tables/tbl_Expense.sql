﻿CREATE TABLE [dbo].[tbl_Expense] (
    [ExpenseId]          INT          IDENTITY (1, 1) NOT NULL,
    [EmployeeId]         INT          NULL,
    [DateOfRequest]      DATETIME     NULL,
    [ExpenseType]        VARCHAR (50) NULL,
    [Amount]             MONEY        NULL,
    [ExpenseDescription] VARCHAR (50) NULL,
    [Status]             VARCHAR (50) NULL,
    [ManagerId]          INT          NULL,
    [ManagerName]        VARCHAR (50) NULL,
    CONSTRAINT [PK_tbl_Expense] PRIMARY KEY CLUSTERED ([ExpenseId] ASC)
);

