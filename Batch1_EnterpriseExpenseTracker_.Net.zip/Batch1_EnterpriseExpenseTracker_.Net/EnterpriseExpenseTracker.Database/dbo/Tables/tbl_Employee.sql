﻿CREATE TABLE [dbo].[tbl_Employee] (
    [EmployeeId]   INT          IDENTITY (1, 1) NOT NULL,
    [EmployeeName] VARCHAR (50) NOT NULL,
    [Designation]  VARCHAR (50) NOT NULL,
    [Project]      VARCHAR (50) NOT NULL,
    [Password]     VARCHAR (50) NOT NULL,
    CONSTRAINT [PK_tbl_Employee] PRIMARY KEY CLUSTERED ([EmployeeId] ASC)
);

