import React from 'react';
import Image from './image';
import NavbarAdmin from './NavBar';



const DashBoard = () => {
 
  return (
    <div>
      
      <Image />
    </div>
  );
};

export default DashBoard